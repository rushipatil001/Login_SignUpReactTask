import logo from './logo.svg';
import './App.css';
import { LoginSignup } from './Components/LoginSingup/LoginSignup';

function App() {
  return (
    <div>
        <LoginSignup/>
    </div>
  );
}

export default App;
